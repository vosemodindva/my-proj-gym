import { useState } from "react";
import axios from "../api/axios";
import { useNavigate } from "react-router-dom";

function Login({ onLogin }) {
  const [form, setForm] = useState({ username: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("token/", form);
      localStorage.setItem("refresh", res.data.refresh);
      onLogin(res.data.access);
      navigate("/profile");
    } catch {
      alert("Неверный логин или пароль");
    }
  };

  return (
    <div className="container mt-5 col-md-6">
      <h2 className="mb-4">Вход</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Имя пользователя</label>
          <input
            name="username"
            placeholder="Логин"
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Пароль</label>
          <input
            name="password"
            type="password"
            placeholder="Пароль"
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <button type="submit" className="btn btn-primary">Войти</button>
      </form>
    </div>
  );
}

export default Login;