export default function Home() {
  return <h1>Добро пожаловать в тренажёрный зал "Омежка"</h1>;
}