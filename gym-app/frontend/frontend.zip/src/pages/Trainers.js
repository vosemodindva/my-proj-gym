export default function Home() {
  return <h1>Тренеры</h1>;
}