import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Memberships from "./pages/Memberships";
import Trainers from "./pages/Trainers";
import useAuth from "./hooks/useAuth";

function Navbar() {
  const navigate = useNavigate();
  const isAuthenticated = useAuth();

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark px-3">
      <Link className="navbar-brand" to="/">Омежка</Link>
      <div className="navbar-nav">
        <Link className="nav-link" to="/memberships">Абонементы</Link>
        <Link className="nav-link" to="/trainers">Тренеры</Link>

        {isAuthenticated ? (
          <>
            <Link className="nav-link" to="/profile">Профиль</Link>
            <button className="btn btn-sm btn-outline-light ms-2" onClick={handleLogout}>
              Выйти
            </button>
          </>
        ) : (
          <>
            <Link className="nav-link" to="/login">Вход</Link>
            <Link className="nav-link" to="/register">Регистрация</Link>
          </>
        )}
      </div>
    </nav>
  );
}

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/memberships" element={<Memberships />} />
          <Route path="/trainers" element={<Trainers />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;